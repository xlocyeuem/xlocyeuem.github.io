<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    date_default_timezone_set('Asia/Ho_Chi_Minh'); // Set timezone to Vietnam

    $response = $_POST['response'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Get public IP address using api.ipify.org
    $ipAddress = @file_get_contents('https://api.ipify.org');
    $ipAddress = $ipAddress ? $ipAddress : 'Unknown';

    // Get country information using ipinfo.io API
    $ipInfo = @file_get_contents("http://ipinfo.io/{$ipAddress}/json");
    $ipInfo = $ipInfo ? json_decode($ipInfo, true) : [];
    $country = isset($ipInfo['country']) ? $ipInfo['country'] : 'Unknown';

    $logEntry = date('Y-m-d H:i:s') . " - IP: $ipAddress - Country: $country - User Agent: $userAgent - Response: $response" . PHP_EOL;

    file_put_contents('../log/info', $logEntry, FILE_APPEND);
}
?>
